module.exports={
    MONGOURI:'mongodb+srv://insta-clone:insta-clone1234@cluster0.wkdwu.mongodb.net/<dbname>?retryWrites=true&w=majority',
    JWT_SECRET:'djsndfjknfjkscmmdnfjsnf'
}