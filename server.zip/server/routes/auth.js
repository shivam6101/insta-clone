const express=require("express");
//const { Mongoose } = require("mongoose");
const router=express.Router()
const mongoose = require("mongoose")
const User=mongoose.model("User")
const bcrypt=require("bcrypt")
const jwt=require("jsonwebtoken")
const {JWT_SECRET}=require("../keys")
const requirelogin=require("../middleware/loginrequire")

router.get('/protected',requirelogin,(req,res)=>{
    res.send("weclom")
})
router.post('/signup',(req,res)=>{
    const{name,email,password}=req.body
    if(!name || !email || !password){
        return res.status(422).json({error:"not correct"})
    }
    User.findOne({email:email})
    .then((savedUser)=>{
        if(savedUser){
            return res.status(422).json({error:"email already used"})
        }
        bcrypt.hash(password,12)
        .then (hashpassword=>{
            const user= new User({
                email,
                password:hashpassword,
                name
            })
            user.save()
            .then(user=>{
                res.json("saved sucessfully")
            })
            .catch(err=>{
                console.log(err)
            })
        })
        
    })
    .catch(err=>{
        console.log(err)
    })
})
router.post("/signin",(req,res)=>{
    const {email,password}=req.body
    if(!email || !password){
        return res.status(422).json({error:"enter email and password"})
    }
    User.findOne({email:email})
    .then(savedUser=>{
        if(!savedUser){
            return res.status(422).json({error:"invalid email or password"})
        }
        bcrypt.compare(password,savedUser.password)
        .then(doMatch=>{
            if(doMatch){
                const token=jwt.sign({_id:savedUser.id},JWT_SECRET)
                const {_id,name,email}=savedUser
                res.json({token,user:{_id,name,email}})
                //res.json({message:"sucessfull sign in"})
            }
            else{
                return res.status(422).json({error:"incorrect email or password"})
            }
    })
    .catch(err=>{
        console.log(err)
    })
})
})

module.exports=router